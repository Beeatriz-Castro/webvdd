type Props = {
  isActive: boolean;
}

export const BrushIcon = ({ isActive }: Props) => {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g clipPath="url(#clip0_131_465)">
        <path d="M10.9697 2H8.96973C3.96973 2 1.96973 4 1.96973 9V15C1.96973 20 3.96973 22 8.96973 22H14.9697C19.9697 22 21.9697 20 21.9697 15V13" stroke={isActive ? "#FFAA00" : "#000000"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M21.8804 3.55998C20.6504 6.62998 17.5604 10.81 14.9804 12.88L13.4004 14.14C13.2004 14.29 13.0004 14.41 12.7704 14.5C12.7704 14.35 12.7604 14.2 12.7404 14.04C12.6504 13.37 12.3504 12.74 11.8104 12.21C11.2604 11.66 10.6004 11.35 9.92043 11.26C9.76043 11.25 9.60043 11.24 9.44043 11.25C9.53043 11 9.66043 10.77 9.83043 10.58L11.0904 8.99998C13.1604 6.41998 17.3504 3.30998 20.4104 2.07998C20.8804 1.89998 21.3404 2.03998 21.6304 2.32998C21.9304 2.62998 22.0704 3.08998 21.8804 3.55998Z" stroke={isActive ? "#FFAA00" : "#000000"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M12.7801 14.49C12.7801 15.37 12.4401 16.21 11.8101 16.85C11.3201 17.34 10.6601 17.68 9.87009 17.78L7.90009 17.99C6.83009 18.11 5.91009 17.2 6.03009 16.11L6.24009 14.14C6.43009 12.39 7.89009 11.27 9.45009 11.24C9.61009 11.23 9.77009 11.24 9.93009 11.25C10.6101 11.34 11.2701 11.65 11.8201 12.2C12.3601 12.74 12.6601 13.36 12.7501 14.03C12.7701 14.19 12.7801 14.35 12.7801 14.49Z" stroke={isActive ? "#FFAA00" : "#000000"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M15.8203 11.9799C15.8203 9.88994 14.1303 8.18994 12.0303 8.18994" stroke={isActive ? "#FFAA00" : "#000000"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      </g>
      <defs>
        <clipPath id="clip0_131_465">
          <rect width="24" height="24" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
}