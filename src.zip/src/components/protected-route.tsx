import { Navigate, Outlet } from "react-router";
import { useAuth } from "@/lib/auth-context";

export function ProtectedRoute() {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/signin" replace />;
  }

  return <Outlet />;
}
